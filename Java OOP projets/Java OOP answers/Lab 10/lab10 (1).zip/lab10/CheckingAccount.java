package lab10;

public class CheckingAccount {
    double balance;

    public CheckingAccount() {
        this.balance = 0;
    }

    public void deposit(double amount){
        if (amount > 0){
            balance += amount;
        }
        System.out.println("You deposit $" + amount);
    }

    public void withdraw(double amount) throws InsufficientFundsException {
        if (amount > balance){
            System.out.println("Sorry, but you are short $" + (amount - balance));
            throw new InsufficientFundsException("You are exiting. The current amount is ", balance);
        }else{
        	
        	balance-=amount;
            System.out.println("You withdraw $" + amount);
        }
    }

    public double getBalance() {
        return balance;
    }
}
