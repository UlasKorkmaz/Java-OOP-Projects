package lab10;

import java.util.Scanner;

public class ExceptionHandling {
    public static void checkAge(int input) throws MyException {
        if (input == 18   ){
        	throw new MyException();
        	
        }
        }
    
    public static void main(String[] args) {
    	
        try{
            Scanner scan = new Scanner(System.in);
            System.out.println("Please Enter the size of the array (small number is recommended): ");
            String size = scan.nextLine();
            
            int sz = 0;
            
            if (size.chars().allMatch(Character::isDigit)){
            	
                sz = Integer.parseInt(size);
                
            }
            else{
            	
                throw new NumberFormatException(size);
            }
            String array[] = new String[sz];

            System.out.println("Enter the city names and put 'end' at the end.");
            int a = 0;
            String inp = scan.nextLine();
            for (String str: inp.split(" ")){
                if (!str.equals("end")){
                    array[a] = str;
                    a++;
                }
            }

            System.out.print("Please enter the index of letter to read from first city name: ");
            
            int index = scan.nextInt();
            
            System.out.println(array[0].charAt(index));

            System.out.print("Please enter a value to divide 25. ");
            
            int div = scan.nextInt();
            
            System.out.println(25 /div);

            System.out.println("Please enter your age:");
            
            int age = scan.nextInt();
            if (age>=18) {
            	
            	
            	checkAge(age);
            	
            	 System.out.println("Access granted.");
                 
                 System.out.println("End of program.");
            }
            
            
            else {
            	
            	  System.out.println("Access denied - You must be at least 18 years old.");
            	  }

          

        }catch (NumberFormatException ex){
            System.out.println("Size is not numeric. For input string: " +"\""+ ex.getMessage()+"\"");
        }catch (ArrayIndexOutOfBoundsException ex){
            System.out.println("The values are more than the size of the array."+ ex.getMessage() );
        }
        catch (StringIndexOutOfBoundsException ex){
            System.out.println("The index is greater than the length of the string." + ex.getMessage());
        }
        catch (ArithmeticException ex){
            System.out.println("You tried to divide a number with zero. " + ex.getMessage());
        }
        catch (MyException ex){
            System.out.println("MyException is thrown. " + ex.getMessage());
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }finally{
            System.out.println("This code block always runs.");
        }

    }}