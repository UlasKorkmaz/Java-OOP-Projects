package lab10;

public class MyException  extends Exception{
	

	
}
