package lab10;

public class InsufficientFundsException extends Exception{

    double amount;

    public InsufficientFundsException(String message, double amount) {

        super(message + amount);

        this.amount = amount;
    }
}
