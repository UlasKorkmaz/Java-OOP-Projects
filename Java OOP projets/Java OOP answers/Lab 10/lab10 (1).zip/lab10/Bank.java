package lab10;
import java.util.Scanner;

public class Bank {
    public static void main(String[] args) throws InsufficientFundsException {
        CheckingAccount checkingAccount = new CheckingAccount();;
        
        
        
        try{


            Scanner scanner = new Scanner(System.in);
            System.out.println("Account id created. Do you want to deposit initial money?")	;
            checkingAccount.deposit(scanner.nextDouble());
            
            
            while(true){
                System.out.println("Do you want to deposit or withdraw money? D or W\n(E for exit)");
                String input = scanner.next();
                if (input.equals("D")){
                    System.out.println("Please enter the amount:");
                    double amount = scanner.nextDouble();
                    checkingAccount.deposit(amount);
                }else if(input.equals("W")){
                    System.out.println("Please enter the amount:");
                    int amount = scanner.nextInt();
                    checkingAccount.withdraw(amount);
                }else if(input.equals("E")){
                    System.out.println("You are exiting. The current amount is $" + checkingAccount.getBalance());
                    break;
                }else{
                    System.out.println("Please enter D, W or E");
                }
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }
}

