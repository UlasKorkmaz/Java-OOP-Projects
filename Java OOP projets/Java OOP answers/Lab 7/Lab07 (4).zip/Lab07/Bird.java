
public class Bird extends Animal {


	private String fly;
	

	public String getMove() {
		
		return fly;
	}
	
	public void setMove(String action) {
		
		
		this.fly="flies";
	}
	
	
public void getBodyIndex(double num) {
	
	System.out.println(this.getClass().getSimpleName() + "getBodyIndex method is invoked");
	
	System.out.println("Body index: " + (this.weight/this.height)*num);
	
}

public void move() {
	
	super.move();
	
	System.out.println(this.getClass().getSimpleName()+ " move method is invoked");

	System.out.println("The animal " + this.getClass().getSimpleName() + " flies");
}


public boolean equals(Object o) {
if (o == null){
    return  false;
}
if (this.getClass() != o.getClass()){
    return false;
}
if (this.getClass() == o.getClass()){
    return true;
          
}


Bird bird = (Bird) o;
return this.height == bird.height && this.name.equals(bird.getName()) && this.fly == bird.getMove();
}



public String toString() {
    return "height:"+ "\t" + height + "weight:"+ "\t" + weight + "name:" + "\t"+ name;
}

	





	
	
	
	
	
	
	
	
}
