
public class Cat extends Animal {

	public String walk;
	

	public String getMove() {
		
		return walk;
	}
	
	public void setMove(String action) {
		
		
		this.walk="walks";
	}
	
	
public void getBodyIndex(double num) {
	

	System.out.println(this.getClass().getSimpleName() + "getBodyIndex method is invoked");
	
	System.out.println("Body index: " + (this.weight/this.height)*num);
	
}
	


public void move() {
	
	super.move();
	
	System.out.println(this.getClass().getSimpleName()+ " move method is invoked");

	System.out.println("The animal " + this.getClass().getSimpleName() + "Walks");
}

	
public boolean equals(Object o) {
    if (o == null){
        return  false;
    }
    if (this.getClass() != o.getClass()){
        return false;
        
        
        
    }
    
    if (this.getClass() == o.getClass()){
        return true;
              
    }
    Cat cat = (Cat) o;
    return this.height == cat.height && this.name.equals(cat.getName()) && this.weight==cat.weight && this.walk == cat.getMove();
}


public String toString() {
    return "height:"+ "\t" + height + "weight:"+ "\t" + weight + "name:" + "\t"+ name;
}

	
	
	
	
}
