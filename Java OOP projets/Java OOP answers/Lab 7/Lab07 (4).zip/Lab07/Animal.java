
public class Animal {

	protected double height;
	protected double weight;
	protected String name;
	
	
	public double getHeight() {
		
		return height;
		
	}
	
	

    public void setHeight(double height) {
        this.height=height;
    }
	
	
	public double getWeight() {
		
		return weight;
		
	}
	
	public void setWeight(double weight) {
		
		this.weight=weight;
			
	}
	
	public String getName() {
		
		return name;
		
	}
	
	
	public void setName(String name) {
		
		this.name=name;
		
		
	}
	

	  public void getBodyIndex() {
	
		 
		 System.out.println(this.getClass().getSimpleName() +" getBodyIndex method is invoked");
		
		 
   System.out.println("Body index: " + (this.weight/this.height));
		 
	    }
	

	
	
	public void move() {
		
		System.out.println(this.getClass().getSimpleName()+ " move method is invoked");
		System.out.println("Every "+this.getClass().getSimpleName()+" Has a movement type");
		
	}
	
	 public boolean equals(Object o) {
	
		        if (o == null ){
		      return  false;
		            
		        }      
		  if (this.getClass() != o.getClass()){
		      return false; }
		  
		       
		       
		       if (this.getClass() == o.getClass()){
		     return true;
		                 
		       }
  
	        Animal animal = (Animal) o;
	        return this.height == animal.height && this.weight==animal.weight && this.name.equals(animal.getName()) ;
	        
	    }
	 
	 public String toString() {
		    return "height:" + height + "weight:" + weight + "name:"+ name;
		}

			
			
			
}
