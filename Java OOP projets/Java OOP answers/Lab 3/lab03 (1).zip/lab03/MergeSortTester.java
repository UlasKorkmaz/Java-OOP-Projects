import java.util.Arrays;

public class MergeSortTester {
	
public static void main(String[] args) {
	
	
int [] arr1= {1,2,4,7,8,11};
int [] arr2= {3,6,8,9,10,11,12,14};

int[] arrr = new int[arr1.length + arr2.length];
int i = 0, j = 0, k = 0;



while (i < arr1.length && j < arr2.length)
{
    if (arr1[i] < arr2[j])
        {
        arrr[k] = arr1[i];
        i++;
        }
    else
         {
        arrr[k] = arr2[j];
        j++;
        }
    k++;
}

while (i < arr1.length)
         {
    arrr[k] = arr1[i];
    i++;
    k++;
         }

while (j < arr2.length)
         {
    arrr[k] = arr2[j];
    j++;
    k++;
        }

System.out.println("New Array:" + Arrays.toString(arrr));

System.out.println("Max value is:" + Sorter.getMaxValue(arrr));
System.out.println("Min value is:" +Sorter.getMinValue(arrr));
return;

















}
}
