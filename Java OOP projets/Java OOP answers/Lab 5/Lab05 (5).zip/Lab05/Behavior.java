package lab055;

public  interface Behavior {

	public String tellName(); 
	public int tellSalary(); 
	public int step(int actualDailyStep); 
	
	
}
