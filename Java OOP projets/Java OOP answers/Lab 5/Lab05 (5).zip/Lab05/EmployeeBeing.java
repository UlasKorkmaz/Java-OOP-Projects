package lab055;

import java.util.Objects;

public class EmployeeBeing  implements Behavior, Comparable {

	 
	    private String name;
	    private int salary;
	    private int dailystep;
	    private static int EmployeeBeing = 0;

	    public EmployeeBeing(String name, int salary) {
	        this.name = name;
	        this.salary = salary;
	
	     
	        EmployeeBeing++;
	    }

	    public static int getNumberEmployee(){
	        return EmployeeBeing;
	    }

	
	    public String tellName() {
	        return name;
	    }

	 
	    public int tellSalary() {
	    	
	    	
	        return salary;
	    }


	    
	    public int step(int actualDailyStep) {
	    	
	    	this.dailystep=actualDailyStep;
	    	
	        return actualDailyStep;
	    }
	
	    public String toString() {
	        return  "Name : " + name +", Salary : " + tellSalary() + ", Step: " + dailystep;
	                
	    }

		
		public int compareTo(Object o) {
			// TODO Auto-generated method stub
			
			 EmployeeBeing employee = (EmployeeBeing) o;
			if (Objects.equals(this.name, employee.name) && this.salary == employee.salary)
			    return 10;


		  else if(!Objects.equals(this.name, employee.name) && this.salary ==  employee.salary)
			    return 0;


		  else if(!Objects.equals(this.name, employee.name) && this.salary < employee.salary )
			    return -1;


		else if(!Objects.equals(this.name, employee.name) && this.salary > employee.salary )
			     return 1;

			  return 99999;
			    }
		 String comparePeople(EmployeeBeing employee){
		        int cv = this.compareTo(employee);
		        if(cv == 10){
		        	
		      return this.name + " and " + employee.name + " are the same persons";
		            
		        }else if(cv == 0){
		        	
		      return this.name + " and " + employee.name + " make the same money ";
		        }
		        else if(cv == 1){
		        	
		      return this.name + " makes more money than " + employee.name;
		        }
		        else if(cv == -1){
		        	
		       return this.name + " makes less money than " + employee.name;
		        }
		        return "Unknow";
		    }}

	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    


